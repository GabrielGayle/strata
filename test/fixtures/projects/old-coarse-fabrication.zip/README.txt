Strata fabrication pack — coarse, Oct 16
Contains project.strata.json from an older export.
